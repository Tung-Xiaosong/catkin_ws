# Open Karto

Catkinized ROS Package of the OpenKarto Library (LGPL3)

# Status

 * Devel Job Status: [![Build Status](http://build.ros.org/buildStatus/icon?job=Mdev__open_karto__ubuntu_bionic_amd64)](http://build.ros.org/job/Mdev__open_karto__ubuntu_bionic_amd64/)
 * AMD64 Debian Job Status: [![Build Status](http://build.ros.org/buildStatus/icon?job=Mbin_uB64__open_karto__ubuntu_bionic_amd64__binary)](http://build.ros.org/job/Mbin_uB64__open_karto__ubuntu_bionic_amd64__binary/)
